﻿namespace Message.Infrastructure
{
    public class Class1
    {

    }
}