﻿

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using RabbitMQ.Client;
using RabbitMqGenericFramwork;

namespace Message.Infrastructure
{
    public static class InfraServiceRegistration
    {
        public static IServiceCollection AddInfrastructureServices(this IServiceCollection services,IConfiguration configuration)
        {

            services.AddSingleton<IConnectionFactoryWrapper, ConnectionFactoryWrapper>();

            services.AddSingleton<IConnection>(sp =>
            {
                var factoryWrapper = sp.GetRequiredService<IConnectionFactoryWrapper>();
                return factoryWrapper.GetConnection();
            });
            services.AddSingleton<IChannelWrapper, ChannelWrapper>();
            services.AddSingleton<IRabbitMQConsumerService, RabbitMQConsumerService>();
            services.AddSingleton<IDatabaseService, DatabaseService>();
            return services;
        }
    }
}
