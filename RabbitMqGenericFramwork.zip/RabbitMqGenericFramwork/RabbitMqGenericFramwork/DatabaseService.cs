﻿namespace RabbitMqGenericFramwork
{
    public class DatabaseService : IDatabaseService
    {
        public DatabaseService(IRabbitMQConsumerService rabbitMQConsumerService)
        {
            rabbitMQConsumerService.OnMessageReceived += SaveMessageToDatabase;
        }

 

        public void SaveMessageToDatabase(string message)
        {
         Console.WriteLine(message);
        }
    }
}
