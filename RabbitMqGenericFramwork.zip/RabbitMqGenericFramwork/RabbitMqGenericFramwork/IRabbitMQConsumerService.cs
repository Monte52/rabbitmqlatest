﻿using static RabbitMQConsumerService;

namespace RabbitMqGenericFramwork
{
    public interface IRabbitMQConsumerService
    {
        void Consume(string exchange, string queue, string routingKey);
        void StartConsumers();

        event MessageReceivedHandler OnMessageReceived;
        //void StartNewConsumersBasedOnNewSettings(RabbitMQSettings rabbitMQSettings);
    }
}
