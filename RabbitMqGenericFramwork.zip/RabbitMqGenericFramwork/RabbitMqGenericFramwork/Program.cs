using MediatR;
using Message.Application;
using RabbitMQ.Client;
using RabbitMqGenericFramwork;
using System.Reflection;

var builder = WebApplication.CreateBuilder(args);

// Added services to the container.
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddApplicationServiceRegistaration();
//builder.Services.AddMediatR(cfg => cfg.RegisterServicesFromAssemblies(Assembly.GetExecutingAssembly()));
var rabbitMQSettings = new RabbitMQSettings();
builder.Configuration.GetSection("RabbitMQ").Bind(rabbitMQSettings);
builder.Services.AddSingleton<IRequestFactory, RequestFactory>();

builder.Services.AddSingleton(rabbitMQSettings);

builder.Services.AddSingleton<IConnectionFactoryWrapper, ConnectionFactoryWrapper>();

builder.Services.AddSingleton<IConnection>(sp =>
{
    var factoryWrapper = sp.GetRequiredService<IConnectionFactoryWrapper>();
    return factoryWrapper.GetConnection();
});
builder.Services.AddSingleton<IChannelWrapper, ChannelWrapper>();
builder.Services.AddSingleton<IRabbitMQConsumerService, RabbitMQConsumerService>();
builder.Services.AddSingleton<IDatabaseService, DatabaseService>();


var app = builder.Build();

// Watch for changes in the configuration file.
//app.Configuration.GetReloadToken().RegisterChangeCallback(async (_) =>
//{
//    // Reload the RabbitMQ settings
//    var newSettings = new RabbitMQSettings();
//    app.Configuration.GetSection("RabbitMQ").Bind(newSettings);

//    // Start new consumers based on the new settings
//    var rabbitMQConsumerService = app.Services.GetRequiredService<IRabbitMQConsumerService>();
//    rabbitMQConsumerService.StartNewConsumersBasedOnNewSettings(newSettings);

//}, null);


// Fetch Queue Names and Start Consumers
var rabbitMQConsumerService = app.Services.GetRequiredService<IRabbitMQConsumerService>();
rabbitMQConsumerService.StartConsumers();
var messageProcessor = app.Services.GetRequiredService<IDatabaseService>();
// Manually call SaveMessageToDatabase for testing

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();

app.Run();


