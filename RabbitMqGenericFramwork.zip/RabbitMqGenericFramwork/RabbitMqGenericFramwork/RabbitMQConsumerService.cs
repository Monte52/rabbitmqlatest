﻿using MediatR;
using Message.Application.Features.MessageConsumer.Event;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using RabbitMqGenericFramwork;
using System;
using System.Collections.Concurrent;
using System.Text;

public class RabbitMQConsumerService : IRabbitMQConsumerService
{
    private readonly IChannelWrapper _channelWrapper;
    private readonly RabbitMQSettings _rabbitMQSettings;
    private readonly IRequestFactory _requestFactory;
    private readonly HashSet<string> _runningQueues = new HashSet<string>();
    public delegate void MessageReceivedHandler(string message);
    public event MessageReceivedHandler OnMessageReceived;
    private readonly IMediator _mediator;
    public RabbitMQConsumerService(IChannelWrapper channelWrapper, RabbitMQSettings rabbitMQSettings, IMediator mediator, IRequestFactory requestFactory)
    {
        _channelWrapper = channelWrapper;
        _rabbitMQSettings = rabbitMQSettings;
        _mediator = mediator;
        _requestFactory = requestFactory;
    }
    public void StartConsumers()
    {
        if (!_rabbitMQSettings.Enable)
        {
            return;
        }

        foreach (var receiver in _rabbitMQSettings.Receivers)
        {
            var key = receiver.Key;
            var settings = receiver.Value;

        
            if (!_runningQueues.Contains(key))
            {
         
               // Consume(settings.Exchange, settings.Queue, settings.RoutingKey);
                Task.Run(() => Consume(settings.Exchange, settings.Queue, settings.RoutingKey));
           
                _runningQueues.Add(key);
            }
        }
    }
    public void Consume(string exchange, string queue, string routingKey)
    {
        _channelWrapper.DeclareQueue(queue);
        _channelWrapper.BindQueue(queue, exchange, routingKey);
        var consumer = new EventingBasicConsumer(_channelWrapper.Channel);  // Use the exposed IModel object
        consumer.Received += (model, ea) =>
        {
            var body = ea.Body.ToArray();
            var message = Encoding.UTF8.GetString(body);
            OnMessageReceived?.Invoke(message);

            //var mediatrRequest = new RabbitMQMessageRequestEvent { Message = message };

            var request = _requestFactory.CreateRequest(exchange, queue, message);

            var processedMessage = _mediator.Send(request).Result;


            Console.WriteLine($"Received from {queue}: {message}");
        };

        _channelWrapper.BasicConsume(queue, consumer);
    }

 


}


