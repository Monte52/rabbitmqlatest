﻿using MediatR;

namespace RabbitMqGenericFramwork
{
    public class RequestFactory : IRequestFactory
    {

        public IRequest<string> CreateRequest(string exchange, string queue, string message)
        {
            var requestType = AppDomain.CurrentDomain
                .GetAssemblies()
                .SelectMany(a => a.GetTypes())
                .FirstOrDefault(t => t.Name == exchange);

            if (requestType != null)
            {
                var request = Activator.CreateInstance(requestType);
                if (request != null)
                {
                    // Assuming Exchange, Queue, and Message properties exist on all request types
                    var exchangeProperty = requestType.GetProperty("Exchange");
                    var queueProperty = requestType.GetProperty("Queue");
                    var messageProperty = requestType.GetProperty("Message");

                    if (exchangeProperty != null)
                        exchangeProperty.SetValue(request, exchange); // Set it with the 'exchange' parameter, not 'requestName'

                    if (queueProperty != null)
                        queueProperty.SetValue(request, queue);

                    if (messageProperty != null)
                        messageProperty.SetValue(request, message);

                    if (request is IRequest<string> unitRequest)
                    {
                        return unitRequest;
                    }

                }
            }

            throw new ArgumentException($"Invalid request name '{exchange}'");
        }



    }
}
