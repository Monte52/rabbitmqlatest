﻿using static RabbitMQConsumerService;

namespace RabbitMqGenericFramwork
{
    public interface IDatabaseService
    {
        //void SaveMessageToDatabase(IRabbitMQConsumerService rabbitMQConsumerService);
    }
}
