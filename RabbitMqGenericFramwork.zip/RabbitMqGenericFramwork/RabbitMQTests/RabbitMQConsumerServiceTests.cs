﻿
using Moq;
using NUnit.Framework;
using RabbitMQ.Client.Events;
using RabbitMqGenericFramwork;
using System.Collections.Generic;

namespace RabbitMQTests
{
    [TestFixture]
    public class RabbitMQConsumerServiceTests
    {
        private Mock<IChannelWrapper> _channelWrapperMock;
        private RabbitMQSettings? _rabbitMQSettings;
        private RabbitMQConsumerService? _service;

        [SetUp]
        public void Setup()
        {
          
            _channelWrapperMock = new Mock<IChannelWrapper>();

      
            _rabbitMQSettings = new RabbitMQSettings
            {
                Enable = true,
                Receivers = new Dictionary<string, RabbitMQReceiver>
            {
                { "TestKey", new RabbitMQReceiver { Exchange = "TestExchange", Queue = "TestQueue", RoutingKey = "TestRoutingKey" } }
            }
            };

         
           // _service = new RabbitMQConsumerService(_channelWrapperMock.Object, _rabbitMQSettings);
        }

        [Test]
        public void StartConsumers_DoesNothing_WhenSettingsDisabled()
        {
            // Arrange
            _rabbitMQSettings.Enable = false;
           // var service = new RabbitMQConsumerService(_channelWrapperMock.Object, _rabbitMQSettings);

            // Act
          //  service.StartConsumers();

            // Assert
            _channelWrapperMock.Verify(x => x.DeclareQueue(It.IsAny<string>()), Times.Never);
        }

        [Test]
        public void Consume_DeclaresAndBindsQueue()
        {
            // Arrange

            // Act
            _service.Consume("exchange", "queue", "routingKey");

            // Assert
            _channelWrapperMock.Verify(x => x.DeclareQueue("queue"), Times.Once);
            _channelWrapperMock.Verify(x => x.BindQueue("queue", "exchange", "routingKey"), Times.Once);
        }

        [Test]
        public void Consume_StartsConsumingMessagesFromQueue()
        {
            // Arrange
        
            string queueName = "test-queue";

            // Act
            _service.Consume("test-exchange", queueName, "test-routingKey");

            // Assert
            _channelWrapperMock.Verify(x => x.BasicConsume(queueName, It.IsAny<EventingBasicConsumer>()), Times.Once);
        }

        [Test]
        public void StartConsumers_ShouldCallDeclareQueue()
        {
            // Act
            _service.StartConsumers();

            // Assert
            _channelWrapperMock.Verify(x => x.DeclareQueue(It.IsAny<string>()), Times.Once);
        }

        [Test]
        public void StartConsumers_ShouldCallBindQueue()
        {
            // Act
            _service.StartConsumers();

            // Assert
            _channelWrapperMock.Verify(x => x.BindQueue(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()), Times.Once);
        }
    }
}
