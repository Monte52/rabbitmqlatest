﻿namespace MessageConsumer
{
    public class Class1
    {

    }
}