﻿using MediatR;

namespace Message.Application.Features.MessageConsumer.Event
{
    public class RabbitMQMessageRequestEventHandler : IRequestHandler<TestExchange1, string>
    {
        public Task<string> Handle(TestExchange1 request, CancellationToken cancellationToken)
        {
            string processedMessage = $"Processed: {request.Message}";

            return Task.FromResult(processedMessage);
        }
    }
}
