﻿using MediatR;

namespace Message.Application.Features.MessageConsumer.Event
{
    public class TestExchange1 : IRequest<string>
    {
        public string Exchange { get; set; }
        public string Queue { get; set; }
        public string Message { get; set; }

    }
}
