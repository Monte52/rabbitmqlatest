﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Message.Application.Features.MessageConsumer.Event
{
    public class SecondRabbitMQMessageRequestEventHandler : IRequestHandler<TestExchange2, string>
    {
        public Task<string> Handle(TestExchange2 request, CancellationToken cancellationToken)
        {
            string processedMessage = $"Processed: {request.Message}";

            return Task.FromResult(processedMessage);
        }
    }
}
