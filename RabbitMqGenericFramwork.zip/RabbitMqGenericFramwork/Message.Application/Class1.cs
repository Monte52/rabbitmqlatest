﻿namespace Message.Application
{
    public class Class1
    {

    }
}